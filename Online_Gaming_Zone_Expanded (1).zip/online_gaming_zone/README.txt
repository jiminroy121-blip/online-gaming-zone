ONLINE GAMING ZONE — EXPANDED WEBSITE

Included:
- index.html: responsive catalog with search, category filters, sorting, favourites, and external game links.
- logo.png: custom site logo.

How to test:
1. Keep index.html and logo.png in the same folder.
2. Double-click index.html to open it in a modern browser.
3. For publishing, upload the files to GitHub Pages or Cloudflare Pages.

Catalog:
- Expanded to more than 45 curated game links and genre collections.
- Search and category filters work locally in the browser.
- Displayed ratings are sample editorial ratings, not live global rankings.
- Many links lead to third-party game directories or game pages; availability and free access can vary by country, device, and publisher.

Important:
- This is a static front-end site, not yet deployed publicly.
- Sign-in and join buttons are demo notices; there is no account backend.
- Games are linked to their respective publishers/platforms, not copied or hosted here.
- Verify current terms, age ratings, accessibility, and link destinations before promoting the site.
